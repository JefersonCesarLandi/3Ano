<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'tecnico');

/** MySQL database username */
define('DB_USER', 'admin');

/** MySQL database password */
define('DB_PASSWORD', '123abc456');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'XPC#U:^Qw|rn>T)!)o)<I1e{*#?~&w{?GT0 2dc{YUc+TEH@Ca9|lqS84L7ORu`j');
define('SECURE_AUTH_KEY',  'F!SbbhXQB6n|Ubj^u*&9?V1.WlFBpp;a@UW dKD_>pN[{l<dIwsko)g.AaUP}p/u');
define('LOGGED_IN_KEY',    '(rr`LcQ$Yx/XUQp_>@yBM 9DeCun@PGsDWvKupkFX/k&TbtUGhDdu>*g>S|8Z4FL');
define('NONCE_KEY',        'W(I-eJdgXsH[QLh G4l(w.{4gKIUX=^@z8wMW&cY=`L.nTP5ye0>>NTd27{};9ul');
define('AUTH_SALT',        'Xd}SJE#L2X/E^FO5Jbr?F3%7~*&)sToTBxdXLO^^2Ik:{=S(%| WbPM3( 0yRUsz');
define('SECURE_AUTH_SALT', 'KxH&kLmn(&<Q_[i|fSi2[}e( yxe>g80;SVZBD1!3vSsg]c/U1.>&M9GHP0zv0o ');
define('LOGGED_IN_SALT',   'E/X5g}BOH:%-A~~U8XXH*Z)AG_Mk.vi]EnbI^sjt[3Qp4SS9z`.G<+i`g>ARdKZI');
define('NONCE_SALT',       'eDWz:j|9Lsp;vV@nDruX}<.S$xkP{f#`2HS|)}7wkGB(@rqx:GqCX3;ic]vPMfU ');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wpII_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
